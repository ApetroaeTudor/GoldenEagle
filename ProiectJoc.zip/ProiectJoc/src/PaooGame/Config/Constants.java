package PaooGame.Config;

public class Constants {
    public static final int WINDOW_WIDTH=1350; //1920x1080 * 0.7
    public static final int WINDOW_HEIGHT=750;


}
