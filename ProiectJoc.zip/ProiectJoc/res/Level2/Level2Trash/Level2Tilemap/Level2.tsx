<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.0" name="Level2" tilewidth="16" tileheight="16" tilecount="512" columns="32">
 <image source="Level2Textures.png" width="512" height="256"/>
</tileset>
