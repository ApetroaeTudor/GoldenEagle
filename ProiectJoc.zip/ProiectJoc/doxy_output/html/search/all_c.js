var searchData=
[
  ['npc_268',['NPC',['../classPaooGame_1_1Entities_1_1NPC.html#a5eda9f20589f8fd95181b4ca08301977',1,'PaooGame.Entities.NPC.NPC()'],['../classPaooGame_1_1Entities_1_1NPC.html',1,'PaooGame.Entities.NPC']]],
  ['nrofframes_269',['nrOfFrames',['../classPaooGame_1_1Animations_1_1Animation.html#ad5a63fa7aee0aa588e5076e5f916b837',1,'PaooGame::Animations::Animation']]],
  ['nullifyhitbox_270',['nullifyHitbox',['../classPaooGame_1_1Entities_1_1Entity.html#aa124f650cbaf3f7a41233f949a4077f4',1,'PaooGame::Entities::Entity']]]
];
