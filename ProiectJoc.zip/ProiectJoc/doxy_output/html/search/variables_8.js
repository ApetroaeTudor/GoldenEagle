var searchData=
[
  ['levelheightintiles_861',['levelHeightInTiles',['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#a51b6cde44d30119c054df79b1d72dde7',1,'PaooGame::Strategies::EnemyStrategies::EnemyStrategy']]],
  ['levelwidthintiles_862',['levelWidthInTiles',['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#a42977c0d6d3af4a38a67dcad3b779348',1,'PaooGame::Strategies::EnemyStrategies::EnemyStrategy']]]
];
