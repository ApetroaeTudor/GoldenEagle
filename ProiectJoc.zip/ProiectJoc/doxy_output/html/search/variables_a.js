var searchData=
[
  ['nrofframes_864',['nrOfFrames',['../classPaooGame_1_1Animations_1_1Animation.html#ad5a63fa7aee0aa588e5076e5f916b837',1,'PaooGame::Animations::Animation']]]
];
