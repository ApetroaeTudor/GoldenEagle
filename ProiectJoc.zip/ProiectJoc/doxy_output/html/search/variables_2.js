var searchData=
[
  ['damage_828',['damage',['../classPaooGame_1_1Entities_1_1Entity.html#ad1b4a6dcd093a4a2bca444708c0a1319',1,'PaooGame.Entities.Entity.damage()'],['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#a1c5f78707cf955c170de3fcac46e953b',1,'PaooGame.Strategies.EnemyStrategies.EnemyStrategy.damage()']]],
  ['defence_829',['defence',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#a0e70cdd8f1ae3bc504cf07ad5c3b6736',1,'PaooGame::Strategies::Fight::FightStrategy']]]
];
