var searchData=
[
  ['health_836',['health',['../classPaooGame_1_1Entities_1_1Entity.html#a82f065a949448571f52fd4cd2699e7ac',1,'PaooGame.Entities.Entity.health()'],['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#a2a7326f60a8ba09bf648d281e60f8bc6',1,'PaooGame.Strategies.EnemyStrategies.EnemyStrategy.health()']]],
  ['healthbarcolor1_837',['healthBarColor1',['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#a6ad14cbb3cfb200d84ce16ae0074c9bc',1,'PaooGame::Strategies::EnemyStrategies::EnemyStrategy']]],
  ['healthbarcolor2_838',['healthBarColor2',['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#aa02bb046a0dbcd81c641e3d2d7a4f457',1,'PaooGame::Strategies::EnemyStrategies::EnemyStrategy']]],
  ['healthbarheight_839',['healthBarHeight',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#af822c9d8534e7e53b11ae10edc65925c',1,'PaooGame::Strategies::Fight::FightStrategy']]],
  ['healthbarwidth_840',['healthBarWidth',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#ac74d797079f3c54f0dbf055d78650a10',1,'PaooGame::Strategies::Fight::FightStrategy']]],
  ['healthbarx_841',['healthBarX',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#a580f9c2ed297ea46c9bf88efba037ecd',1,'PaooGame::Strategies::Fight::FightStrategy']]],
  ['healthbary_842',['healthBarY',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#a3a6cf2d569c459ae0b70a7cb1273da53',1,'PaooGame::Strategies::Fight::FightStrategy']]],
  ['height_843',['height',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#aaf324e1f76217ae7a1627f995505c59a',1,'PaooGame::Strategies::Fight::FightStrategy']]],
  ['hitbox_844',['hitbox',['../classPaooGame_1_1Entities_1_1Entity.html#aa69542bc8275bf0e4a7e983a85353059',1,'PaooGame.Entities.Entity.hitbox()'],['../classPaooGame_1_1Items_1_1Item.html#aba63551028c0008287489869a0a363a9',1,'PaooGame.Items.Item.hitbox()']]],
  ['hitboxheight_845',['hitboxHeight',['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#a5fe550b7111c353b9a57d0325c5300e7',1,'PaooGame::Strategies::EnemyStrategies::EnemyStrategy']]],
  ['hitboxwidth_846',['hitboxWidth',['../classPaooGame_1_1Strategies_1_1EnemyStrategies_1_1EnemyStrategy.html#ad61e273f7732ee041da179e5a5f7bfa8',1,'PaooGame::Strategies::EnemyStrategies::EnemyStrategy']]]
];
