var searchData=
[
  ['npc_695',['NPC',['../classPaooGame_1_1Entities_1_1NPC.html#a5eda9f20589f8fd95181b4ca08301977',1,'PaooGame::Entities::NPC']]],
  ['nullifyhitbox_696',['nullifyHitbox',['../classPaooGame_1_1Entities_1_1Entity.html#aa124f650cbaf3f7a41233f949a4077f4',1,'PaooGame::Entities::Entity']]]
];
