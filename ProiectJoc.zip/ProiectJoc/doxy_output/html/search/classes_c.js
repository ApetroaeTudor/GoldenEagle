var searchData=
[
  ['npc_459',['NPC',['../classPaooGame_1_1Entities_1_1NPC.html',1,'PaooGame::Entities']]]
];
