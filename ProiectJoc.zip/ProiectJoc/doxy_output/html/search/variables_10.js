var searchData=
[
  ['velocityx_876',['velocityX',['../classPaooGame_1_1Entities_1_1Entity.html#ac7a5cab7d370e9cf3983827eef35d264',1,'PaooGame::Entities::Entity']]],
  ['velocityy_877',['velocityY',['../classPaooGame_1_1Entities_1_1Entity.html#afbbb7e0d7668467ce3b2dfc637a44a28',1,'PaooGame::Entities::Entity']]]
];
