var searchData=
[
  ['ownerstate_865',['ownerState',['../classPaooGame_1_1Strategies_1_1Fight_1_1FightStrategy.html#a72ea772661c936a839301b9e607b11a5',1,'PaooGame::Strategies::Fight::FightStrategy']]]
];
